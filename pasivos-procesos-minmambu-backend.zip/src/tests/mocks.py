mock_typeproduct_schema = {
    "producttypedescription": "TEST",
    "producttypemaestrosunicos":"123",
    "producttype":"CDT",
    "user": "USER-TEST"
}

mock_massive_account_creation = [
    {
        "filename": "Prueba_Flujo_CDT_001-202201211621718.xlsx",
        "results_per_row": [],
        "file_id": "202201211621718",
        "date_upload": "2022-01-21",
        "user_upload": "",
        "upload_type": "CDT",
        "original_filename": "Prueba_Flujo_CDT_001.xlsx"
    }
]